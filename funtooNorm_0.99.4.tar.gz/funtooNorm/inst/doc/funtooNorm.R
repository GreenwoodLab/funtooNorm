### R code from vignette source 'funtooNorm.Rnw'

###################################################
### code chunk number 1: funtooNorm.Rnw:127-133
###################################################
    require(funtooNorm)
    require(minfiData)
    # Here some fictive cell types are given for demonstration
    pData(RGsetEx)$cell_type <- rep(c("type1","type2"),3)
    
    mySampleSet=fromRGChannelSet(RGsetEx)


###################################################
### code chunk number 2: funtooNorm.Rnw:143-145
###################################################
    origBeta <- getRawBeta(mySampleSet)
    origBeta[1:3,1:3]


###################################################
### code chunk number 3: funtooNorm.Rnw:178-179
###################################################
    plotValidationGraph(mySampleSet, type.fits="PCR")


###################################################
### code chunk number 4: funtooNorm.Rnw:193-197
###################################################
    mySampleSet=funtooNorm(mySampleSet,type.fits="PCR",ncmp=3)
    mySampleSet
    normBeta <- getNormBeta(mySampleSet)
    normBeta[1:3,1:3]


###################################################
### code chunk number 5: funtooNorm.Rnw:210-213
###################################################
    # Again, technical replicates are fictive, just for demonstration
    agreement(origBeta, c(1:5,5)) # M for data before the normalization
    agreement(normBeta, c(1:5,5)) # M for data after normalization


###################################################
### code chunk number 6: funtooNorm.Rnw:223-224
###################################################
library(minfi)


###################################################
### code chunk number 7: funtooNorm.Rnw:234-237
###################################################
    age=pData(RGsetEx)$age
    dmp=dmpFinder(getNormM(mySampleSet), age, type="continuous")
    dmp[1:2,]


###################################################
### code chunk number 8: funtooNorm.Rnw:254-255
###################################################
phenoData <- pData(RGsetEx)[,c("age","sex","status")]


###################################################
### code chunk number 9: funtooNorm.Rnw:258-265
###################################################
genomerange <- getGRanges(mySampleSet)

grs <- GenomicRatioSet(gr=genomerange,
                       Beta=normBeta,
                       preprocessMethod="funtooNorm",
                       pData=phenoData)



###################################################
### code chunk number 10: funtooNorm.Rnw:271-272
###################################################
grs


