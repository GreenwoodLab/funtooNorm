### R code from vignette source 'funtooNorm.Rnw'

###################################################
### code chunk number 1: funtooNorm.Rnw:127-132
###################################################
    require(funtooNorm)
    require(minfiData)
    # Here some fictive cell types are given for demonstration
    pData(RGsetEx)$cell_type <- rep(c("type1","type2"),3)
    mySampleSet=fromRGChannelSet(RGsetEx)


###################################################
### code chunk number 2: funtooNorm.Rnw:142-144
###################################################
    origBeta <- getRawBeta(mySampleSet)
    origBeta[1:3,1:3]


###################################################
### code chunk number 3: funtooNorm.Rnw:177-178
###################################################
    plotValidationGraph(mySampleSet, type.fits="PCR")


###################################################
### code chunk number 4: funtooNorm.Rnw:192-196
###################################################
    mySampleSet=funtooNorm(mySampleSet,type.fits="PCR",ncmp=3)
    mySampleSet
    normBeta <- getNormBeta(mySampleSet)
    normBeta[1:3,1:3]


###################################################
### code chunk number 5: funtooNorm.Rnw:209-212
###################################################
    # Again, technical replicates are fictive, just for demonstration
    agreement(origBeta, c(1:5,5)) # M for data before the normalization
    agreement(normBeta, c(1:5,5)) # M for data after normalization


###################################################
### code chunk number 6: funtooNorm.Rnw:222-223
###################################################
library(minfi)


###################################################
### code chunk number 7: funtooNorm.Rnw:233-236
###################################################
    age=pData(RGsetEx)$age
    dmp=dmpFinder(getNormM(mySampleSet), age, type="continuous")
    dmp[1:2,]


###################################################
### code chunk number 8: funtooNorm.Rnw:253-254
###################################################
phenoData <- pData(RGsetEx)[,c("age","sex","status")]


###################################################
### code chunk number 9: funtooNorm.Rnw:257-264
###################################################
genomerange <- getGRanges(mySampleSet)

grs <- GenomicRatioSet(gr=genomerange,
                       Beta=normBeta,
                       preprocessMethod="funtooNorm",
                       pData=phenoData)



###################################################
### code chunk number 10: funtooNorm.Rnw:270-271
###################################################
grs


